export class Doctor {
  registrationNumber!: string;
  name!: string;
  age!: number;
  gender!: string;
  specialization!: string;
  patientsAttended!: number;
}
